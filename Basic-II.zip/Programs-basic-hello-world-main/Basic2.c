//2.Accept two numbers and display their addition:


#include<stdio.h>
int main()
{
   int a,b;
   printf("Enter two num:");
   scanf("%d %d",&a,&b);
   printf("Sum of two numbers=%d",a+b);
   
   return0;
 }  
