//9.Display sizeof variable using size of oprator:

#include<stdio.h>
int main()
{
  int Int_var;
  char Char_var;
  float Float_var;
  double Double_var;
  
  
  printf("size of int:%d",sizeof(Int_var));
  printf("\nsize of char:%d",sizeof(Char_var));
  printf("\nsize of float:%d",sizeof(Float_var));
  printf("\nsize of double:%d",sizeof(Double_var));
  
  return 0;
  
 } 
  
