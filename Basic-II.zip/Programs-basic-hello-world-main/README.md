<h4>Hello World! welcome to c world!<h4>                    starting with Basic Programs::<h4><br><br>
  
  
1. Accept two numbers and display them.<Br>
2. Accept two numbers and display their addition.<Br>
3. Accept 5 numbers and give their average.<Br>
4. Accept marks of 3 subjects and display percentage.<Br>
5. Accept 5 characters and display them in reverse order.<Br>
6. Accept a lower case character and convert it into upper case.<Br>
7. Accept two numbers & display quotient and remainder of division.<Br>
8. Accept principle, rate and time and then calculate Simple Interest. (p*r*t)/100<Br>
9. Display the size of variable using sizeof operator.<Br>
