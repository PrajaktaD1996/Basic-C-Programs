//7.Accept two numbers and display quotient and reminder of division::

#include<stdio.h>
int main()
{
  int num1,num2;
  printf("Enter the two numbers :");
  scanf("%d%d",&num1,&num2);
  printf("\nQuotient=%d",num1/num2);
  printf("\nReminder=%d",num1%num2);
  
  return 0;
  
 } 
