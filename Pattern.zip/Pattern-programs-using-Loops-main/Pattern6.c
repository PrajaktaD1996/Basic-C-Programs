#include<stdio.h>
void main()
{
     int i,j;
     for(i=0;i<6;i++)
       {
               for(j=5;j>i;j--)
               printf(“ “);
               
               for(i=0;j<I;j++)
               printf(“* ”);

                printf(“\n”);
         }
     
      for(i=0;i<4;i++)
        {
                 for(j=0;j<I;j++)
                 printf(“ ”);
                 
                  for(j=4;j>I;j--)
                  printf(“* “);
                      
                  printf(“\n”);
          }
    }

