#include<stdio.h>
void main()
{
    int I,j;
    for(i=1;i<7;i++)
    {
           for(j=6;j>I;j--)
           printf(“ “);

           for(j=i-1;j>0;j--)
           printf(“%d”,j);

            for(j=2;j<I;j++)
            printf(“%d”,j)’

              Printf(“\n”);
       }
}
