#include<stdio.h>
void main()
{
     int(i=0;i<4;i++)
       {
             for(j=4;j>i;j--)
             printf(" ");
              
              for(j=i;j>=0;j--)
              printf("%c",j+65);

              printf("\n");
        }
    }   

