#include<stdio.h>
void main()
{
   int i,j,n=1;
  for(i=1;i<6;i++)
   {
        for(j=1;j<I;j++)
        {
              printf(“%d ”,n);
              n=n+2;
           }
           printf(“\n”);
      }
   } 
