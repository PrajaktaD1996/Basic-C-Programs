#include<stdio.h>
void main()
{
     int i,j;
     for(i=0;i<6;i++)
       {
             for(j=5;j>i;j--)
             printf(“ “);
             
              for(j=0;j<I;j++)
               printf(“\n”);
          }
        }

