#include <stdio.h>

int main()
{
    int i,s=0;
    printf("The sum of 10 numbers is:");
    for(i=1;i<=10;i++)
    s=s+i;
    
    printf("%d",s);
    return 0;
}
