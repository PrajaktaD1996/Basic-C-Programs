# Programs-using-Loops

1. write a program to display addition of 1 to 10<br>
2. print first 10 odd numbers<br>
3. Print the multiplication table of given number<br>
4. Accept m & n from user , print table of m up to n<br>
5. Accept 10 numbers from user and display counts of even and odd<br>
6. Accept 10 numbers from user and display addition of all odd numbers<br>
7. Find square of a given number pmwithout using * operator<br>
8. display the addition of digits of a given number<br>
9. check whether the given number is Armstrong<br>
10. check whether the given number is prime<br>
11. check whether the given number is palindrome or not<br>
12. find the factorial of given number<br>
13. print the Fibonacci series<br>
14. print first 50 prime numbers<br>
15. write a program to convert given number into binary & display it<br>
