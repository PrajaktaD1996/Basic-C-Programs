#include <stdio.h>

int main()
{
    int i,num,sq;
    
    printf("Enter the value of num:");
    scanf("%d",&num);
    for(i=0;i<num;i++)
       sq=sq+num;
         
    printf("The square of numbers:%d",sq);
     
    
    return 0;
}
