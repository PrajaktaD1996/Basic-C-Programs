#include <stdio.h>

int main()
{
    int i;
    printf("First 10 odd numbers is:");
    
    for(i=1;i<=20;)
    {
        printf("%d ",i);
        i=i+2;
    }    
        
    
    return 0;
}
