# Programs-on-2d-strings


1. Write a program to scan & display 2d character array str[5][15]<br>
2. Write a program to calculate & display the length of each string in 2d character array arr[3][20]<br>
3. Write a program to scan 2d character array & a character, find & display how many times that
character appears in 2d array<br>
4. Write a program to find & display number of vowels & consonants in 2d array arr[4][10]<br>
