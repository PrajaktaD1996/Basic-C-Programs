#include<stdio.h>
#include<string.h>

void main()
{
  int i,j;
  char str[5][15];

  printf("Enter 5 strings::\n");
  for(i=0;i<;i++)
  scanf("%s",str[i]);

  printf("\nDisplay:\n");
  for(i=0;i<5;i++)
  printf("%s\n",str[i]);
}
