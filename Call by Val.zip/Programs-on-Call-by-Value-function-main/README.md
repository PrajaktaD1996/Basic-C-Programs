# Programs-on-Call-by-Value-function



1. Write a program to do addition of 3 numbers & display the addition in called function.<br>
2. Write a program to do addition of 3 numbers & display the addition in main function.<br>
3. Write a program to find the factorial of given number , display the result in called function.<br>
4. Write a program to find whether the given number is prime or not, display the result message in
called function.<br>
5. Write a program to display addition of digits of a number, display the result in main function.<br>
6. Write a program to check whether given number is palindrome or not, display the result
message in main function.<br>
7. Write a program to swap two numbers & display them in called function.<br>
