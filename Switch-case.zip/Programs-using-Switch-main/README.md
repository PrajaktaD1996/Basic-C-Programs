# Programs-using-Switch


1.write a menu driven calculator program (+.addition +.subtraction /.division *.multiplication)<br>
2.write a program to accept a number and print wek day accordingly (Monday for 1, Tuesday for 2,
Wednesday for 3……..Sunday for 7)<br>
3.write a program to find whether given number is even or odd<br>
4. write a program to find whether given character is vowel or consonant<br>
