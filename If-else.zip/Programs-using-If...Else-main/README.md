# Programs-using-If...Else


1. Find whether given no is even or odd<br>
2. Find whether given character is vowel or consonant<br>
3. Find whether given no is positive or negative<br>
4. Find whether given character is alphabet or number<br>
5. Find whether given year is leap year or not<br>
6. Check whether given character is lower or uppercase<br>
