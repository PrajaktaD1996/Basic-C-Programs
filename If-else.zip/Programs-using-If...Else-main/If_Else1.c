//1.Find Weather the number is even or odd::

#include<stdio.h>
int main()
{
  int num;
  printf("Enter the number:");
  scanf("%d",&num);
  
  if(num%2==0)
  printf("\nNum is Even");
  
  else
  printf("\nNum is Odd");
  
  return 0;
  
 } 
