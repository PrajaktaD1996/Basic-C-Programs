//6.Check weather given character is in lower case or in upper case:

#include<stdio.h>
int main()
{
  char ch;
  printf("Enter the charachter:");
  scanf("%c",&ch);
  
  if(ch>='A'&&ch<='Z')
    printf("The charachter is in upper case:");
        
  else
     printf("The charachter is in lower case:");
     
  return 0;
} 
  
