//3.Find whether given number is positive or negative:

#include<stdio.h>
int main()
{
  int num;
  printf("\nEnter the integer number:");
  scanf("%d",&num);
  
  if(num<0)
   printf("The number(%d) is negetive!",num);
   
  else
   printf("The number(%d) is positive!",num);
   
   
   return 0;
 }  
