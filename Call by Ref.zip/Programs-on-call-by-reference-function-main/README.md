# Programs-on-call-by-reference-function


1. Write a program to accept a number in main function, increment it by 10 in called function &
display the result in main function.<br>
2. Write a program to accept a character in main function, if its lower case convert it into upper
case, if its upper case convert it into lower case (in called function) & display the converted
character in main function.<br>
3. Write a program to accept array of 10 integer elements in main function, do the addition of
elements of array in called function & display the result in main function(using index method).<br>
4. Do the above program using pointer method<br>
5. Write a program to accept a string in main function, convert all characters of string in upper
case(in called function)& display the converted string in main function(using index method)<br>
6. Do the above program using pointer method<br>
7. Write a program to accept array of 10 integer elements in main function, assign a pointer to
array, pass the pointer to called function & display the array in called function.<br>
8. Write a program to accept array of 10 character elements in main function, assign a pointer to
array, pass the pointer to called function & display the array in called function.<br>
9. Write a program to accept two strings in called function, concatenate them & display the
concatenated string in called function<br>
10. Write a program to pass 3 pointers to function & display the concatenated string in main
function.<br>
Example : str1[]=”hello”; str2[]=”welcome”; str3[20];
P1=str1; p2=str2; p3=str3;
<br>Prototype of function : void concat(char * , char *, char *);
Call of function : void concat(p1,p2,p3);
