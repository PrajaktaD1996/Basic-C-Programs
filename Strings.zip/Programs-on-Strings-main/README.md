# Programs-on-Strings


1. Write a program to accept string from user & find its length<br>
2. Write a program to accept one string from user , & copy it into another empty string<br>
3. Write a program to accept one string from user , & copy it into another empty string in reverse
order, display the reverse string<br>
4. Write a program to count number of vowels & number of consonants in the string<br>
5. Write a program to convert all the characters of string into uppercase & display string<br>
6. Write a program to accept two strings from user & compare them, display whether they are
equal or not<br>
7. Write a program to accept one string from user & reverse it without using second string<br>
8. Write a program to accept two strings from user & concatenate them and display concatenated
string (e.g. - str1[20]=”hello” str2[10]=”welcome”…………after concatenation str1 should
become hellowelcome)<br>
9. Write a program to accept two strings from user & insert the second string into first after the
character specified by user (e.g.- str1[20]=”hello” str2[10]=”welcome”….if user specifies e
str1 should become hewelcomello)<br>
10. Write a program to check whether the given string is palindrome or not, without using second
string<br>
