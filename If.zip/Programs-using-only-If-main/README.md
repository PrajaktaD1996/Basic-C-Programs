# Programs-using-only-If<br><br>


1. Accept two numbers & find greater of them.<br>
2. Accept two numbers and subtract smaller value from bigger.<br>
3. Menu driven program to calculate area of <br>1.circle 2.square 3.rectangle
(3.14*r*r)(side*side)(length*breadth) (char….upper & lower case).<br>
4. Accept marks of three subjects calculate percentage & display the class<br>
Less than 50%= pass class<br>
50 to 60% = second class<br>
60 to 74% = first class<br>
75 % & Above = distinction<br>
5. Find greatest of 3 numbers using only if<br>


