//1.Accept two numbers and find greater of them::

#include<stdio.h>
int main()
{
  int num1,num2;
  printf("Enter two numbers:");
  scanf("%d%d",&num1,num2);
  
  if(num1>num2)
   printf("%d is greater",num1);
  
  if(num1<num2)
    printf("%d is greater",num2);
    
  return 0;
}  
