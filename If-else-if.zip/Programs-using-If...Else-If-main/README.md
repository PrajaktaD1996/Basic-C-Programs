# Programs-using-If...Else-If


1. Find the greatest of three numbers using<br>
2. Accept number from user & display day of the week accordingly(sunday)<br>
3. Find whether given character is alphabet or number, if it is alphabet find whether it is vowel or consonant, if its number find whether it’s even or odd
