#include<stdio.h>
void main()
{
  int num;
  printf("\nEnter num:");
  scanf("%d",&num);
  
  printf("\nQuotient %d/2:%d",num,num>>1);
}
