#include<stdio.h>
void main()
{
  int num;
  printf("\nEnter num:");
  scanf("%d",&num);
  
  printf("\nProduct %dx4:%d",num,num<<2);
}
 
