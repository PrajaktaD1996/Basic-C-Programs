# Programs-on-bitwise-operator


1 Wap to reset the 4th bit of an character variable without affecting other bits<br>
2 Wap to set the 2nd bit of an character variable without affecting other bits<br>
3 Wap to compliment the 7th bit of character variable without affecting other bits<br>
4 Wap to multiply given number by 4 without using arithmetic operators<br>
5 Wap to divide given number by 2 without using arithmetic operators<br>
6 Wap to disassemble the hexadecimal number(stored in a character variable)& display each digit
separately.<br>
7 Wap a program to swap lower & upper nibble of hexadecimal number (stored in a character
variable ).<br>
8 Wap to set 28 th bit of integer variable without affecting other bits<br>
9 Wap to reset 3rd and 17th bit of int variable without affecting other bits<br>
