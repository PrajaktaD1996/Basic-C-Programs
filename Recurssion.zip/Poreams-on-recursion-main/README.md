# Pograms-on-recursion


1. Write a program to print 1 to 100 using recursive function<br>
2. Write a program to print 100 to 1 using recursive function<br>
3. Write a program to display the addition of 1 to 10 using recursive function<br>
4. Write a program to accept a number from user in main function ,find its factorial using recursive
function & display the result in main function.<br>
5. wap to find addition of digits of given number<br>
