# Programs-on-Structures


1 Write a program to define a structure variable containing one character, one integer & one
 string. Accept & display all the contents using . operator<br>
 
2 Write a program to define a structure variable containing one character, one integer & one
 string. Accept & display all the contents using -> operator<br>
 
3 Write a program to define a structure variable containing one character, one integer & one
 integer array. Accept & display all the contents using . operator<br>
 
4 Write a program to define a structure variable containing one character, one integer & one
 integer array. Accept & display all the contents using -> operator<br>
 
5 Write a program to define a structure variable containing one character, one integer & one
 integer array. Accept all the contents using . operator, pass the structure variable to function
 (call by value) & display the contents in called function using . operator<br>
 
6 Write a program to define a structure variable containing one character, one integer & one
 float. Accept all the contents using -> operator, pass the structure variable to function (call by
 reference) & display the contents in called function using pointer<br>
 
7 Write a program to define array of structures, each structure containing one character, one
 integer & one float. Accept and display contents of structure using . operator<br>
 
8 Write a program to define array of structures, each structure containing one character, one
 integer & one float. Accept and display contents of structure using pointer (assign a pointer to
 array of structure)<br>
 
9 Write a program to define a structure within the structure. Accept & display all the contents
 using . operator<br>
 
e.g struct abc
{

Int a ;

Char c ;

};

Struct xyz

{

float f;

struct abc m;

}k;<br>

10 Do the above program by assigning pointer to xyz, Accept & display all the contents using
pointer.<br>
