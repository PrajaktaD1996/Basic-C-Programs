# C_programs
C_programming
1.finding factors of two numbers and check weather it is prime or not.
2.finding LCM and HCF of two numbers.
3.finding simple interst and compound interest
